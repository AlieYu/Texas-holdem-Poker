/*************************************************************************
	> File Name: CardsMap.h
	> Author: 
	> Mail: 
	> Created Time: Fri 29 May 2015 10:01:28 AM CST
 ************************************************************************/

#ifndef _CARDSMAP_H
#define _CARDSMAP_H
#include <iostream>
#include <map>
using namespace std;

class CFindProbability//封装map容器并提供查找函数
{
public:
	static double GetProbability(int Cardscode)//通过键值查找概率值
	{
		map<int, double>::const_iterator iter = myCardMap.find(Cardscode);
		if (iter != myCardMap.end())  
        {  
            return iter->second;  
        }  
        else  
        {  
            return 0;  
        }
	}
private:
	static map<int, double> CreateCardMap()//创建map
	{
		map<int, double> CardsMap;
		CardsMap.insert(make_pair(1414, 39.6));
		CardsMap.insert(make_pair(1313, 33.11));
		CardsMap.insert(make_pair(1212, 28.4));
		CardsMap.insert(make_pair(11314, 27.51));
		CardsMap.insert(make_pair(11214, 25.30));
		CardsMap.insert(make_pair(1111, 24.89));
		CardsMap.insert(make_pair(11213, 24.86));
		CardsMap.insert(make_pair(11114, 24.82));
		CardsMap.insert(make_pair(11014, 24.02));
		CardsMap.insert(make_pair(11113, 23.85));
		CardsMap.insert(make_pair(11112, 23.39));
		CardsMap.insert(make_pair(1314, 23.24));
		CardsMap.insert(make_pair(11013, 23.15));
		CardsMap.insert(make_pair(11011, 22.86));
		CardsMap.insert(make_pair(11012, 22.79));
		CardsMap.insert(make_pair(1010, 22.29));
		CardsMap.insert(make_pair(10914, 21.56));
		CardsMap.insert(make_pair(1214, 21.4));
		CardsMap.insert(make_pair(10814, 20.94));
		CardsMap.insert(make_pair(10514, 20.94));
		CardsMap.insert(make_pair(10910, 20.74));
		CardsMap.insert(make_pair(1213, 20.52));

		CardsMap.insert(make_pair(10414, 20.52));
		CardsMap.insert(make_pair(10913, 20.51));
		CardsMap.insert(make_pair(10714, 20.46));
		CardsMap.insert(make_pair(10911, 20.26));
		CardsMap.insert(make_pair(10314, 20.18));
		CardsMap.insert(make_pair(10912, 20.15));
		CardsMap.insert(make_pair(909, 20.14));
		CardsMap.insert(make_pair(1114, 20.08));
		CardsMap.insert(make_pair(10214, 19.88));
		CardsMap.insert(make_pair(10614, 19.35));
		CardsMap.insert(make_pair(1113, 19.3));
		CardsMap.insert(make_pair(1014, 19.16));
		CardsMap.insert(make_pair(10810, 19.15));

		CardsMap.insert(make_pair(1112, 19.06));
		CardsMap.insert(make_pair(10813, 19.04));
		CardsMap.insert(make_pair(808, 18.79));
		CardsMap.insert(make_pair(10809, 18.74));
		CardsMap.insert(make_pair(10811, 18.66));
		CardsMap.insert(make_pair(1011, 18.6));
		CardsMap.insert(make_pair(10713, 18.59));
		CardsMap.insert(make_pair(10812, 18.55));
		CardsMap.insert(make_pair(1013, 18.45));

		CardsMap.insert(make_pair(1012, 18.3));
		CardsMap.insert(make_pair(10513, 17.96));
		CardsMap.insert(make_pair(10708, 17.95));
		CardsMap.insert(make_pair(10613, 17.78));
		CardsMap.insert(make_pair(707, 17.75));

		CardsMap.insert(make_pair(10710, 17.66));
		CardsMap.insert(make_pair(10709, 17.64));
		CardsMap.insert(make_pair(10413, 17.55));
		CardsMap.insert(make_pair(10712, 17.28));
		CardsMap.insert(make_pair(10711, 17.2));
		CardsMap.insert(make_pair(10313, 17.2));
		CardsMap.insert(make_pair(10213, 16.92));
		CardsMap.insert(make_pair(10512, 16.66));
		CardsMap.insert(make_pair(10405, 16.59));
		CardsMap.insert(make_pair(10612, 16.48));
		CardsMap.insert(make_pair(914, 16.46));
		CardsMap.insert(make_pair(606, 16.45));
		CardsMap.insert(make_pair(910, 16.42));
		CardsMap.insert(make_pair(10507, 16.38));
		CardsMap.insert(make_pair(10607, 16.32));
		CardsMap.insert(make_pair(10608, 16.31));
		CardsMap.insert(make_pair(10412, 16.29));
		CardsMap.insert(make_pair(505, 16.19));
		CardsMap.insert(make_pair(10506, 16.04));                               
		CardsMap.insert(make_pair(10312, 15.94));
		CardsMap.insert(make_pair(10610, 15.84));

		CardsMap.insert(make_pair(10609, 15.84));
		CardsMap.insert(make_pair(10511, 15.8));
		CardsMap.insert(make_pair(404, 15.79));
		CardsMap.insert(make_pair(911, 15.76));
		CardsMap.insert(make_pair(814, 15.74));
		CardsMap.insert(make_pair(514, 15.68));
		CardsMap.insert(make_pair(10212, 15.68));
		CardsMap.insert(make_pair(10508, 15.66));
		CardsMap.insert(make_pair(913, 15.59));
		CardsMap.insert(make_pair(10611, 15.59));
		CardsMap.insert(make_pair(303, 15.49));
		CardsMap.insert(make_pair(10305, 15.45));
		CardsMap.insert(make_pair(912, 15.42));
		CardsMap.insert(make_pair(10411, 15.41));
		CardsMap.insert(make_pair(202, 15.36));
		CardsMap.insert(make_pair(414, 15.22));
		CardsMap.insert(make_pair(10510, 15.21));
		CardsMap.insert(make_pair(714, 15.19));

		CardsMap.insert(make_pair(10311, 15.08));
		CardsMap.insert(make_pair(10509, 15.04));
		CardsMap.insert(make_pair(10407, 14.95));
		CardsMap.insert(make_pair(10406, 14.86));
		CardsMap.insert(make_pair(10410, 14.84));
		CardsMap.insert(make_pair(314, 14.84));
		CardsMap.insert(make_pair(10211, 14.81));
		CardsMap.insert(make_pair(10304, 14.74));
		CardsMap.insert(make_pair(810, 14.7));
		CardsMap.insert(make_pair(214, 14.54));
		CardsMap.insert(make_pair(10310, 14.48));
		CardsMap.insert(make_pair(809, 14.38));
		CardsMap.insert(make_pair(10408, 14.22));
		CardsMap.insert(make_pair(10210, 14.22));
		CardsMap.insert(make_pair(10205, 14.14));
		CardsMap.insert(make_pair(811, 14));
		CardsMap.insert(make_pair(614, 13.99));
		CardsMap.insert(make_pair(813, 13.98));

		CardsMap.insert(make_pair(10409, 13.82));
		CardsMap.insert(make_pair(812, 13.69));
		CardsMap.insert(make_pair(10204, 13.69));
		CardsMap.insert(make_pair(708, 13.62));

		CardsMap.insert(make_pair(10307, 13.54));
		CardsMap.insert(make_pair(10306, 13.49));
		CardsMap.insert(make_pair(10309, 13.48));
		CardsMap.insert(make_pair(713, 13.46));
		CardsMap.insert(make_pair(10209, 12.90));
		CardsMap.insert(make_pair(709, 13.19));
		CardsMap.insert(make_pair(10203, 13.1));
		CardsMap.insert(make_pair(710, 13.09));
		CardsMap.insert(make_pair(10308, 13.02));
		CardsMap.insert(make_pair(10208, 12.76));
		CardsMap.insert(make_pair(513, 12.74));
		CardsMap.insert(make_pair(613, 12.56));

		CardsMap.insert(make_pair(711, 12.44));
		CardsMap.insert(make_pair(10207, 12.41));
		CardsMap.insert(make_pair(405, 12.35));
		CardsMap.insert(make_pair(413, 12.31));
		CardsMap.insert(make_pair(712, 12.29));
		CardsMap.insert(make_pair(10206, 12.21));
		CardsMap.insert(make_pair(507, 12.04));
		CardsMap.insert(make_pair(607, 11.94));
		CardsMap.insert(make_pair(313, 11.91));
		CardsMap.insert(make_pair(608, 11.86));
		CardsMap.insert(make_pair(506, 11.71));
		CardsMap.insert(make_pair(213, 11.64));
		CardsMap.insert(make_pair(512, 11.62));
		CardsMap.insert(make_pair(612, 11.41));
		CardsMap.insert(make_pair(609, 11.26));
		CardsMap.insert(make_pair(412, 11.2));
		CardsMap.insert(make_pair(508, 11.19));
		CardsMap.insert(make_pair(305, 11.16));
		CardsMap.insert(make_pair(610, 11.12));
		
		CardsMap.insert(make_pair(511, 10.9));
		CardsMap.insert(make_pair(312, 10.82));
		CardsMap.insert(make_pair(611, 10.68));
		CardsMap.insert(make_pair(212, 10.54));
		CardsMap.insert(make_pair(407, 10.52));
		CardsMap.insert(make_pair(406, 10.49));
		CardsMap.insert(make_pair(510, 10.48));
		CardsMap.insert(make_pair(411, 10.48));
		CardsMap.insert(make_pair(509, 10.41));
		CardsMap.insert(make_pair(304, 10.41));
		CardsMap.insert(make_pair(311, 10.11));
		CardsMap.insert(make_pair(410, 10.05));
		CardsMap.insert(make_pair(211, 9.82));
		CardsMap.insert(make_pair(205, 9.76));
		CardsMap.insert(make_pair(310, 9.68));
		CardsMap.insert(make_pair(408, 9.66));
		CardsMap.insert(make_pair(210, 9.4));
		CardsMap.insert(make_pair(204, 9.3));
		CardsMap.insert(make_pair(409, 9.12));
		
		CardsMap.insert(make_pair(307, 9.02));
		CardsMap.insert(make_pair(306, 9.02));
		CardsMap.insert(make_pair(309, 8.74));
		CardsMap.insert(make_pair(203, 8.66));
		CardsMap.insert(make_pair(209, 8.46));
		CardsMap.insert(make_pair(308, 8.4));
		CardsMap.insert(make_pair(208, 8.1));
		CardsMap.insert(make_pair(207, 7.82));
		CardsMap.insert(make_pair(206, 7.68));
		return CardsMap;
	}
	static const map<int, double> myCardMap;//静态常量
};
	
const map<int, double> CFindProbability::myCardMap = CFindProbability::CreateCardMap();//静态常量的初始化
#endif
