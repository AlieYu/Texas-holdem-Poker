#ifndef _GAME_
#define _GAME_
#include <algorithm>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "Player.h"
#include "CardsMap.h"
#define random(x) (rand()%x)
#define Denominator5 1081
#define Denominator6 46
#define Ave_Weight_5 4.5//Ӧ�û�ҪСһЩ
#define Ave_Weight_6 3.5
#define Alpha 1;
#define Beta 1.5;


using namespace std;

bool operator==(const Card c1,const Card c2)
{
	return((c1.color==c2.color)&&(c1.point==c2.point));
}

//��ŵ�ǰ�����ƿ���ɵ����ͣ�ÿ�����Ͷ�Ӧ�����һλ��1��ʾ����ɸ����ͣ�����Ϊ����
//ֱ����������Ϊ�±�
int isType[9],isType5[9];
double weight;
/***********************************************************************************
***********************************************************************************/
//����ıȽϺ�����
//����������
int comp_point( Card a, Card b)
{
	return a.point < b.point;
	
}

//����ɫ���򣨺� �� ÷ ����
int comp_color(Card a, Card b)
{
	return a.color < b.color;
	
}

//�����Ȱ���ɫ����ͬ���ڲ�����������    pendΪ��β
void CPSort(Card* pbeg,Card* pend)
{
	if(pbeg==NULL)
	{
		return;
	}

	sort(pbeg,pend,comp_color);
	Card* temp1=pbeg;
	Card* temp2=pbeg;
	for(;temp1<pend && temp2<pend;)
	{
		while((temp2+1)->color == temp1->color)
		{
		 ++temp2;
		}
		sort(temp1,++temp2,comp_point);
		temp1=temp2;
	}
}

double Weight_Of_SmallCard(double point)
{
	if (point<=9)
	{
		return 0.6+(point-1)*0.05;
	} 
	else
	{
		return point/10;
	}
}
double Weight_Of_BigCard(double point)
{
		return 0.84+point*0.02;
}
/*�жϸ����� ������ ���������Ƿ������ĳ�����ͣ�����������isType�����ӦλΪ1��
�����ؾ������͵��ƣ������Ƕ�Ӧ����ֵʱ����ʼ��Ϊpoint������*/

//�Ƿ�Ϊͬ��˳  
long long isStraightFlush(Card* cards,int beg,int end,int* istype)
{
	//���Ƚ����ȼ�����
	if(end - beg >=4)
	{
		int flag=0;
		for(int i=end;i!=beg;i--)
		{
			if((cards[i].color == cards[i-1].color)&&(cards[i].point-1 == cards[i-1].point))
			{
				flag++;
				if (flag>=4)
				{
					istype[ctStraightFlush]=1;
					long long result=0;
					result=(long long)ctStraightFlush*10000000000+(long long)cards[i+3].point*100000000 + (long long)cards[i+2].point*1000000 + (long long)cards[i+1].point*10000 + (long long)cards[i].point*100 + (long long)cards[i-1].point*1;
					return result;
				}
			}
			else  if(cards[i].point != cards[i-1].point+1 || cards[i].color!=cards[i-1].color)
			{
				flag=0;
			}
		}
	}
	
	istype[ctStraightFlush]=0;
	return 0; 
}

//�Ƿ�Ϊ����
long long isFourOne(Card* cards,int beg,int end,int* istype)
{
	//���Ƚ����ȼ�����
	if(end - beg >=3 )
	{
		int flag=0;
		for(int i=end;i!=beg;i--)
		{
			if(cards[i].point == cards[i-1].point)
			{
				flag++;
				if (flag>=3)
				{
					istype[ctFourOne]=1;
					long long result=0;
					if (i==end-2)
					{
						if (end - beg ==3)
						{
							result=(long long)ctFourOne*10000000000+(long long)cards[i].point*101010100;
						} 
						else
						{
							result=(long long)ctFourOne*10000000000+(long long)cards[i].point*101010100 + (long long)cards[i-2].point;
						}
						
					} 
					else
					{
						result=(long long)ctFourOne*10000000000+(long long)cards[i].point*101010100 + (long long)cards[i+3].point;
					}
					return result;				
				}
			}
			else  if(cards[i].point != cards[i-1].point )
			{
				flag=0;
			}
		}
	}
	
	istype[ctFourOne]=0;
	return 0;
}



//�Ƿ�Ϊ������
long long isThreeTwo(Card* cards,int beg,int end,int* istype)
{
	if(end-beg >=4)
	{
		for (;beg<3;beg++)
		{
			long long result;
			
			if (cards[beg].point == cards[beg+1].point && cards[beg].point == cards[beg+2].point)
			{
				result=(long long)ctThreeTwo*10000000000+(long long)cards[beg].point*101010000;
				int i= beg+3;
				for (;i<end;i++)
				{
					if (cards[i].point == cards[i+1].point)
					{
							istype[ctThreeTwo]=1;
							result+=(long long)cards[i].point*101;
							return result;
					}
				}
			} 
			else if (cards[beg].point == cards[beg+1].point && cards[beg].point != cards[beg+2].point)
			{
				result=(long long)ctThreeTwo*10000000000+(long long)cards[beg].point*101;
				int i = beg+2;
				for (;i<end-1;i++)
				{
					if (cards[i].point == cards[i+1].point && cards[i].point == cards[i+2].point)
					{	
						istype[ctThreeTwo]=1;
						result+=(long long)cards[i].point*101010000;
						return result;
					}
				}
			}						
		}		
	}
	istype[ctThreeTwo]=0;
	return 0;	
}
//�Ƿ�Ϊͬ��  �����5�����Ѿ�����ɫ����
long long isFlush(Card* cards,int beg,int end,int* istype)
{
	if(end - beg >= 4)
	{
		int flag=0;
		for(int i=end;i!=beg;--i)
		{
			if(cards[i].color==cards[i-1].color)
			{
				flag++;
				if (flag>=4)
				{
					istype[ctFlush]=1;
					long long result=0;
					result=(long long)ctFlush*10000000000+(long long)cards[i+3].point*100000000 + (long long)cards[i+2].point*1000000 + (long long)cards[i+1].point*10000 + (long long)cards[i].point*100 + (long long)cards[i-1].point*1;
					return result;
				}
			}
			else if (cards[i].color!=cards[i-1].color)
			{
				flag=0;
			}
			
		}
	}
	istype[ctFlush]=0;
	return 0;
}

//�Ƿ�Ϊ˳��
long long isStraight(Card* cards,int beg,int end,int* istype)
{
	if(end - beg >=4 )
	{
		int flag=0;
		for(int i=end;i!=beg;--i)
		{
			if(cards[i].point-1 == cards[i-1].point)
			{
				flag++;
				if (flag>=4)
				{
					istype[ctStraight]=1;
					long long result=0;
					result=(long long)ctStraight*10000000000+(long long)(cards[i].point+3)*100000000 + (long long)(cards[i].point+2)*1000000 + (long long)(cards[i].point+1)*10000 + (long long)cards[i].point*100 + (long long)cards[i-1].point*1;
					return result;
				}
			}
			else  if(cards[i].point-1 > cards[i-1].point  )
			{
				flag=0;
			}
		} 
		flag = 1;
		if(cards[beg].point == p2 && cards[end].point == pA)//�ж�A2345��˳��
		{
			for(int i = beg+1;i<end;i++ )
			{
				if((int)(cards[i].point -p2) == flag)
				{
					flag ++;
					if( flag == 4 )
					{
						istype[ctStraight]=1;
						long long result=0;
						result=(long long)ctStraight*10000000000+(long long)5*100000000 + (long long)4*1000000 + (long long)3*10000 + (long long)2*100 + (long long)pA*1;
						return result;
					}
				}
			}
		}
	}
	istype[ctStraight]=0;
	return 0;	
}

//�Ƿ�Ϊ����
long long isThreeCard(Card* cards,int beg ,int end,int* istype)
{
	if(end - beg >= 2)
	{
		for(int i=end;i!=beg+1;--i)
		{
			if(cards[i].point==cards[i-1].point&&cards[i].point==cards[i-2].point)
			{
				
				istype[ctThreeCard]=1;
				long long result=0;
				result=(long long)ctThreeCard*10000000000+(long long)cards[i].point*101010000;
				if(end - beg ==2)
				{
					result += 0;
				}
				else if (end - beg == 3)
				{
					if (i == end)
						result+=(long long)cards[i-3].point*100;
					else 
						result+=(long long)cards[i+1].point*100;
				} 
				else
				{
					if (i == end)
					result+=(long long)cards[i-3].point*100+(long long)cards[i-4].point;
					else if (i == end-1)
						result+=(long long)cards[i+1].point*100+(long long)cards[i-3].point;
					else 
						result+=(long long)cards[end].point*100+(long long)cards[end-1].point;				
				}
				return result;		
			}
		}
	}
	istype[ctFlush]=0;
	return 0;
}
	
//�Ƿ�Ϊ����
long long isTwoPair(Card* cards,int beg,int end,int* istype)
{
	if(end-beg>3)
	{
		for (int i=end;i>beg+2;i--)
		{
			if (cards[i].point == cards[i-1].point)
			{
				long long result=0;
				result=(long long)ctTwoPair*10000000000+(long long)cards[i].point*101000000;
				for (int j=i-2;j>beg;j--)
				{
					if (cards[j].point == cards[j-1].point)
					{
						istype[ctTwoPair]=1;
						result+=(long long)cards[j].point*10100;
						if (i<end)
						{
							result+=(long long)cards[end].point;
						} 
						else
						{
							if (j==end-2)
								result+=(long long)cards[j-2].point;
							else
								result+=(long long)cards[end-2].point;
						}
						return result;
					}
				}
			}
		}
	}
	else if (end - beg ==3)
	{
		if (cards[0].point == cards[1].point && cards[2].point == cards[3].point)
		{
			long long result=0;
			result=(long long)ctTwoPair*10000000000+(long long)cards[2].point*101000000 +(long long)cards[0].point*10100;
			return result;
		}
	}
	istype[ctTwoPair]=0; 
	return 0;
}
	
	//�Ƿ�Ϊһ��
long long isOnePair(Card* cards,int beg,int end,int* istype)
{
	if(end-beg>=2)
	{
		for (int i=end;i>beg;i--)
		{
			if (cards[i].point == cards[i-1].point)
			{
				long long result=0;
				result=(long long)ctOnePair*10000000000+(long long)cards[i].point*101000000;
				istype[ctOnePair]=1;
				if (end - beg == 2)
				{
					if (i==end)
						result+=(long long)cards[end-2].point*10000;
					else 
						result+=(long long)cards[end].point*10000;
				}
				else if (end - beg ==3)
				{
					if (i==end)
						result+=(long long)cards[end-2].point*10000+(long long)cards[end-3].point*100;
					else if(i == end-1)
						result+=(long long)cards[end].point*10000+(long long)cards[i-2].point*100;
					else  
						result+=(long long)cards[end].point*10000+(long long)cards[end-1].point*100;
				} 
				else
				{
					if (i==end)
						result+=(long long)cards[end-2].point*10000+(long long)cards[end-3].point*100+(long long)cards[end-4].point;
					else if(i == end-1)
						result+=(long long)cards[end].point*10000+(long long)cards[i-2].point*100+(long long)cards[i-3].point;
					else if (i == end-2)
						result+=(long long)cards[end].point*10000+(long long)cards[end-1].point*100+(long long)cards[i-2].point;
					else
						result+=(long long)cards[end].point*10000+(long long)cards[end-1].point*100+(long long)cards[end-2].point;			
				}
				return result;
			}
		}
	}
	istype[ctOnePair]=0; 
	return 0;
}
	
//�Ƿ�Ϊ����
long long isHighCard(Card*cards,int beg,int end,int* istype)
{
	istype[ctHighCard]=1;
	return 0;
}
long long GetCT_Value(Card* cards,int num)
{
	int array7[9],array5[9];
	for(int i=0;i<9;++i) 
	{
		array7[i]=0;
		array5[i]=0;
	}
	Card* temp_All=new Card[num];
	Card* temp_Pub=new Card[num-2];
	for (int i = 0 ; i< num;i++)
	{
		temp_All[i]=cards[i];
		if (i<5)
		{
			temp_Pub[i]=cards[i+2];
		}
	}

//�Ƿ�Ϊͬ��˳   
	CPSort(temp_All,temp_All+num);
	long long m_value=isStraightFlush(temp_All,0,num,array7);
		if(array7[ctStraightFlush]==1)
		{
			CPSort(temp_Pub,temp_Pub+num-2);
			isStraightFlush(temp_Pub,0,num-3,array5);
			if (array5[ctStraightFlush]==1)//���5�Ź�������ͬ��˳�������Լ�����û�б�ͬ��˳�����ƴ�һ�ŵ���
			{
				Card card_temp;
				card_temp.color=temp_Pub[0].color;
				card_temp.point=Point(temp_Pub[num-3].point+1);
				if (!(cards[0]==card_temp || cards[1]==card_temp))
				{
					return 0;
				}
			}
			return m_value;			
		}
	//�Ƿ�Ϊͬ��

	m_value=isFlush(temp_All,0,num-1,array7);
		if(array7[ctFlush]==1)
		{
			CPSort(temp_Pub,temp_Pub+num-2);
			isFlush(temp_Pub,0,num-3,array5);
			if (array5[ctFlush] == 1)
			{
				if (!(cards[0].color==temp_Pub[0].color && cards[0].point>=temp_Pub[4].point)||(cards[1].color==temp_Pub[0].color && cards[1].point>=temp_Pub[4].point))
				{
					return 0;
				}
			}
			return m_value;
		}
	//�Ƿ�Ϊ����
	sort(temp_All,temp_All+num,comp_point);
	sort(temp_Pub,temp_Pub+num-2,comp_point);

	m_value=isFourOne(temp_All,0,num-1,array7);
		if(array7[ctFourOne]==1)
		{
			isFourOne(temp_Pub,0,num-3,array5);
			if (array5[ctFourOne] == 1)//�ų�������Ϊ4�������
			{
				return 0;
			}
			
			return m_value;
		}
	//�Ƿ�Ϊ��«

	m_value=isThreeTwo(temp_All,0,num-1,array7);
	if(array7[ctThreeTwo]==1)
	{
		isThreeTwo(temp_Pub,0,num-3,array5);//�ų�������Ϊ��«�����
		if (array5[ctThreeTwo]==1)
		{
			if (temp_Pub[0].point!=temp_Pub[2].point)
			{
				if (!(cards[0].point==cards[1].point && cards[0].point>temp_Pub[0].point))
					return 0;
			} 
			else
			{
				if (cards[0].point!=temp_Pub[3].point && cards[1].point!=temp_Pub[3].point)
					return 0;
			}
		}
		return m_value;
	}

	

	//�Ƿ�Ϊ˳��
	m_value=isStraight(temp_All,0,7-1,array7);
	if(array7[ctStraight]==1)
	{
		long long m_PubCardValue = isStraight(temp_Pub,0,num-3,array5);//�ų�������Ϊ˳�ӵ����
		if (array5[ctStraight]==1)//��������ʽ ��֤��tem_Pub[4]�Ĵ���
		{
			if (m_PubCardValue==m_value)
				return 0;
		}		
		return m_value;
	}
	
		
	//�Ƿ�Ϊ����
	m_value=isThreeCard(temp_All,0,num-1,array7);	
		if(array7[ctThreeCard]==1)
		{
			isThreeCard(temp_Pub,0,num-3,array5);
			if (array5[ctThreeCard] == 1)
			{
				return 0;
			}
			return m_value;
		}
	
		
	//�Ƿ�Ϊ����

	m_value=isTwoPair(temp_All,0,num-1,array7);
	if(array7[ctTwoPair]==1)
	{
		long long m_Pubvalue=isTwoPair(temp_Pub,0,num-3,array5);
		if (m_value - m_Pubvalue <= 12 && m_value- m_Pubvalue>=- 12)//�ų�������Ϊ���Ե����
		{
			return 0;
		}
		return m_value;
	}
	

	//�Ƿ�Ϊһ��
	m_value=isOnePair(temp_All,0,num-1,array7);
		if(array7[ctOnePair]==1)
			{
				isOnePair(temp_Pub,0,num-3,array5);
				if(array5[ctOnePair]==1)
					return 0;
				return m_value;
			}


	//�Ƿ�Ϊ����
	isHighCard(cards,0,num-1,array7);
		if(isType[ctHighCard]==1)
			return 0;
    delete[] temp_All;
    delete[] temp_Pub;
}	

//����֪5��6����ʱ ͳ���⸱�����õ��������͵ĸ��� num����֪������
void Possibility_Of_Cards(Card* cards,int num,double* count)
{
	if (num == 5)
	{
		Card temp1,temp2;
			for (int i = 0;i< 52;i++)
			{
				temp1.color=Color(i/13+1); //����ó���ɫ
				temp1.point=Point(i%13+2); //����ó�����
				if (temp1==cards[0]||temp1==cards[1]||temp1==cards[2]||temp1==cards[3]||temp1==cards[4])
				{					
					continue;
				}
				else
				{
					for (int j=i+1;j<52;j++)
					{
						temp2.color=Color(j/13+1);//����ó���ɫ
						temp2.point=Point(j%13+2);//����ó�����
						if (temp2==cards[0]||temp2==cards[1]||temp2==cards[2]||temp2==cards[3]||temp2==cards[4])
						{					
							continue;
						}
						else
						{
							Card* m_temp =new Card[7];
							for (int k=0;k<5;k++)
							{
								m_temp[k]=cards[k];
							}
							m_temp[5]=temp1;
							m_temp[6]=temp2;							
							long long cardvalue = GetCT_Value(m_temp,7);
							switch(cardvalue/10000000000)
							{double point;
							case 0: count[ctHighCard] +=1;
									break;

							case 1: 
									count[ctOnePair]+=Weight_Of_SmallCard((double)(cardvalue-ctOnePair*10000000000)/100000000);
									break;

							case 2: point=(double)(cardvalue-ctTwoPair*10000000000)/100000000;
									count[ctTwoPair]+=Weight_Of_SmallCard(point);
									break;

							case 3: point=(double)(cardvalue-ctThreeCard*10000000000)/100000000;
									count[ctThreeCard]+=Weight_Of_SmallCard(point);
									break;

							case 4: point=(double)(cardvalue-ctStraight*10000000000)/100000000;
									count[ctStraight]+=Weight_Of_SmallCard(point);
									break;

							case 5:  point=(double)(cardvalue-ctFlush*10000000000)/100000000;
									count[ctFlush]+=Weight_Of_SmallCard(point);
									break;

							case 6: count[ctThreeTwo] +=1;
									break;

							case 7: count[ctFourOne] +=1;
									break;

							case 8: count[ctStraightFlush] +=1;
									break;

							default: count[ctHighCard] +=1;
									break;							}
							delete[] m_temp;
						}
					}
				}					
			}
	} 
	else if(num == 6)
	{
		Card temp;
		for (int j=0;j<52;j++)
			{
				temp.color=Color(j/13+1);//����ó���ɫ
				temp.point=Point(j%13+2);//����ó�����
				if (temp==cards[0]||temp==cards[1]||temp==cards[2]||temp==cards[3]||temp==cards[4]||temp==cards[5])
				{					
					continue;
				}
				else
				{
					Card* m_temp =new Card[7];
					for (int k=0;k<6;k++)
					{
						m_temp[k]=cards[k];
					}
					m_temp[6]=temp;
					long long cardvalue = GetCT_Value(m_temp,7);
					switch(cardvalue/10000000000)
					{double point;
					case 0: count[ctHighCard] +=1;
							break;
					case 1: point=(double)(cardvalue-ctOnePair*10000000000)/100000000;
							count[ctOnePair]+=Weight_Of_SmallCard(point);
							break;
					case 2: count[ctTwoPair] +=1;
							break;
					case 3: count[ctThreeCard] +=1;
							break;
					case 4: count[ctStraight] +=1;
							break;
					case 5: count[ctFlush] +=1;
							break;
					case 6: count[ctThreeTwo] +=1;
							break;
					case 7: count[ctFourOne] +=1;
							break;
					case 8: count[ctStraightFlush] +=1;
							break;
					default: count[ctHighCard] +=1;
							break;
					}
					delete[] m_temp;
				}
			}
	}
}
double Action_Of_Hold_Msg(Card* hand_cards)
{
    int code = 0;
    if(hand_cards[0].color == hand_cards[1].color)
    {
        code +=10000;
    }
    if(hand_cards[0].point < hand_cards[1].point)
        code += hand_cards[0].point*100 + hand_cards[1].point*1;
    else
        code += hand_cards[1].point*100 + hand_cards[0].point*1;
    
    return CFindProbability::GetProbability(code);
}

string Action_Of_Inquire_Two_Cards(double weight,int players,int small_blind,int bet_in_turn,int least_call,int PlayerNum,int g_seat,int JuShu,int jetton,int num,int before_players)
{
    weight = weight * log(3+(double)(8-players)/8);
    string result = "";
    if (weight < 13.73 )//12.5*1.0986�������12.5��1/8����ҪС���Ϳ���������
    { 
         if(least_call <=2*small_blind && bet_in_turn == 0 && (num/2.0 + 1 - before_players) <= 0 && num > 4 )
         {
             result = "call \n";
          }
          else if(bet_in_turn != 0 && bet_in_turn + least_call <= 120)
          {
              result = "call \n";
          }
          else
             result = "fold \n";
        
        
    }
    else if (weight < 18.07)//�������� ����Ͷ����äע����һ��
    {
        if(least_call  <= 2*small_blind && bet_in_turn ==0)
        {
            result = "call \n";
        }
        else if(bet_in_turn != 0 && least_call + bet_in_turn <=160 )
        {
            result = "call \n";
        }
        else 
            result = "fold \n";
    }
    else if(weight < 22.12)//������ǿ
    {
        if(g_seat == 1 && least_call == small_blind )//թ��
        {
            srand(JuShu);
            if(random(100) < 25 && jetton >=1000)
            {
                result = "raise 500 \n";
            }
            else
                result = "call \n";
        }
        else if(g_seat == 2 && least_call == 0 )
        {
            srand(JuShu);
            if(random(100) < 35 && jetton >= 1000)
            {
                result = "raise 500 \n";
            }
            else 
                result = "check \n";
        }
        else if(least_call <= 6*small_blind && bet_in_turn ==0)
        {
            result = "call \n";
        }
        else if(bet_in_turn != 0 && least_call <=240)
        {
            result = "call \n";
        }
        else
            result = "fold \n";
    }
    else//����ǿ �����ʵ���ע
    {
        
        if (g_seat == 0  && least_call <= 2*small_blind && num>5 )
        {
            srand(JuShu);
            if(random(100)<20&& jetton > 1100)
            {
                result = "raise 1000 \n";
            }    
            else 
            {    
                result="raise ";
                char buf[8];
                sprintf(buf,"%d",120-bet_in_turn-least_call);
                result=result+buf+" \n";
            }
        }
        else if ((g_seat == 1 || g_seat ==2 ) && least_call <= small_blind )
        {
            srand(JuShu);
            if(random(100)<40&& jetton > 1100)
            {
                result = "raise 1000 \n";
            }    
            else 
            {    
                result="raise ";
                char buf[8];
                sprintf(buf,"%d",120-bet_in_turn-least_call);
                result=result+buf+" \n";
            }
        }
        else if(least_call + bet_in_turn <= 6*small_blind)
        {
            result="raise ";
            char buf[8];
            sprintf(buf,"%d",120-bet_in_turn-least_call);
            result=result+buf+" \n";
        }
        else if(least_call + bet_in_turn <= 15*small_blind)
        {
            result = "call \n";
        }
        else 
            result = "fold \n";
    }
    return result;
}

//�������Ź�����ʱ�Ķ���
double Action_Of_Flop_Msg(Card* hand_cards,Card* PubCards)
{
	Card* m_cards=new Card[5];
	m_cards[0]=hand_cards[0];
	m_cards[1]=hand_cards[1];
	m_cards[2]=PubCards[0];
	m_cards[3]=PubCards[1];
	m_cards[4]=PubCards[2];
    for(int i =0;i<5;i++)
    {
        cout<<"color"<<i+1<<" "<<m_cards[i].color<<"   point"<<i+1<<" "<<m_cards[i].point<<endl;
    }
	double count[9],w;	//weight:Ȩ��
	memset(count,0,sizeof(double)*9);
	Possibility_Of_Cards(m_cards,5,count); 
	w=0;
    w=count[1]*1.28/Denominator5+count[2]*3.26/Denominator5+count[3]*19.7/Denominator5+count[4]*20.65/Denominator5+count[5]*32.05/Denominator5+count[6]*33.52/Denominator5+count[7]*594/Denominator5+count[8]*2093.915/Denominator5;
	return w;
}
//����ת��ʱ�Ķ���
double Action_Of_Turn_Msg(Card* hand_cards,Card* PubCards)
{
	Card* m_cards=new Card[6];
	m_cards[0]=hand_cards[0];
	m_cards[1]=hand_cards[1];
	m_cards[2]=PubCards[0];
	m_cards[3]=PubCards[1];
	m_cards[4]=PubCards[2];
	m_cards[5]=PubCards[3];
	double count[9],w;	//weight:Ȩ��
	memset(count,0,sizeof(double)*9);
	Possibility_Of_Cards(m_cards,6,count); 
	w=0;
    if((count[1] >=20.8 && count[1]<=44.8) && count[2] - 12 < 0.01 && 12-count[2]<0.01 &&count[3] - 2<0.01 && 2- count[3]<0.01 )
    {
        w = 0.1;
        return w;
    }
	for (int i=3 ; i<=8 ; i++)
	{
		w +=count[i];
	}
	w+=count[1]*0.1729+count[2]*0.6106;
	w = w/Denominator6;
	return w;
}
//��������ʱ�Ķ���
double Action_Of_River_Msg(Card* hand_cards,Card* PubCards)
{
	Card* m_cards=new Card[7];
	m_cards[0]=hand_cards[0];
	m_cards[1]=hand_cards[1];
	m_cards[2]=PubCards[0];
	m_cards[3]=PubCards[1];
	m_cards[4]=PubCards[2];
	m_cards[5]=PubCards[3];
	m_cards[6]=PubCards[4];
	double w;
	int sum=0;
	int bigger=0;
	long long m_value = GetCT_Value(m_cards,7);
	if (m_value == 0)
	{
        delete[] m_cards;
	    return 0;
	}
	else 
	{	
		Card temp1,temp2;
		for (int i=0;i<52;i++)
		{
			
			temp1.color=Color(i/13+1); //����ó���ɫ
			temp1.point=Point(i%13+2); //����ó�����
			if (temp1==hand_cards[0]||temp1==hand_cards[1]||temp1==PubCards[0]||temp1==PubCards[1]||temp1==PubCards[2]||temp1==PubCards[3]||temp1==PubCards[4])
			{					
				continue;
			}
			else
			{
				for (int j=i+1;j<52;j++)
				{
					temp2.color=Color(j/13+1);//����ó���ɫ
					temp2.point=Point(j%13+2);//����ó�����
					if (temp2==hand_cards[0]||temp2==hand_cards[1]||temp2==PubCards[0]||temp2==PubCards[1]||temp2==PubCards[2]||temp2==PubCards[3]||temp2==PubCards[4])
					{					
						continue;
					}
					else
					{
						m_cards[0]=temp1;
						m_cards[1]=temp2;
						for (int k=0;k<5;k++)
						{
							m_cards[k+2]=PubCards[k];
						}
						long long opponent_value = GetCT_Value(m_cards,7);
						if (opponent_value>m_value)
						{
							bigger++;
						} 
						sum++;
					}
				}
			}
		}
		w=1-(double)bigger/(double)sum;
        delete[] m_cards;
		return w;
	}
}
//���Ź��ƽ׶���Ҫ�ľ�����Ϊ
string Action_Of_Inquire_Five_Cards(double weight,int jetton,int TotalPot,int bet_of_all,int least_call,int bet_in_turn,int small_blind,int PlayerNum,int num,int before_players)
{
    weight = (weight*8)/(7.2+(double)PlayerNum*0.1);//����Ŀǰ����������ʵ�����Ȩ�أ�
	double Formula_Left=(weight-Ave_Weight_5)/Ave_Weight_5;
	//double Formula_Right=(double)(bet_of_all+least_call)/(double)TotalPot*Alpha + (double)least_call/(double)jetton*Beta;
	if (Formula_Left <= 0 )
	{
        if(least_call > 0 )
        {
            string result="fold \n";
            return result;
        }
        else 
        {
            if(num - 1 == before_players && bet_in_turn == 0)
            {
                if(random(100)<50)
                {
                    string result = "raise 120 \n";
                    return result;
                }
            }
            string result="check \n";
            return result;
        }
    }

	if (least_call == 0)//���ǰ����˶�û�м�ע
	{
        if((num -1 == before_players) && num >= 3)
        {
            string result = "raise 240 \n";
            return result;
        }
        else if(Formula_Left >= 1)
        {
            string result = "raise 40 \n";
            return result;
        }
		else if (Formula_Left > 0.1 )//���1.5ȷ���Լ��Ƿ��ע��Խ����Խ���أ�ԽСԽ����
		{
			if ((double)TotalPot/((double)PlayerNum)<= 120)//ǰһ�ֿ���û����ƽ��ÿ����Ͷע��120����
			{
                string result="raise ";
                char buf[8];
                sprintf(buf,"%d",80);
                result=result+buf+" \n";
                return result;
			}
			else
            {
                string result="raise 40 \n";
                return result;
            }
		} 
		else
		{
            string result="check \n";
            return result;
	    }
    } 
	else//��ע��� �����6/3.5/0.8 �����ж��Լ��������ƻ��߳��Ƶĺû� ���ܻ���Ҫ����ʵ���������������С
	{
        string result;
		if (Formula_Left > 15 && least_call +  bet_in_turn<=80*small_blind)
	    {
            if(bet_in_turn +  least_call <= 30*small_blind)
            {
                result = "raise ";
                char buf[8];
                sprintf(buf,"%d",80);
                result = result + buf +" \n";
            }
            else
			    result="call \n";			
		} 
		else if (Formula_Left>7 && least_call + bet_in_turn<= 40*small_blind)
		{
            if(bet_in_turn + least_call <= 20*small_blind)
            {
                result = "raise ";
                char buf[8];
                sprintf(buf,"%d",120);
                result = result + buf +" \n";
            }
            else
			    result="call \n";			
		}
		else if (Formula_Left>3 && least_call + bet_in_turn<=25*small_blind)
		{
            if(bet_in_turn +least_call <= 15*small_blind)
            {
                result = "raise ";
                char buf[8];
                sprintf(buf,"%d",160);
                result = result + buf +" \n";
            }
            else
			    result="call \n";			
		}
		else if (Formula_Left>1 && least_call +  bet_in_turn<=20*small_blind)
		{
            if(bet_in_turn+least_call<= 15*small_blind)
            {
                result = "raise ";
                char buf[8];
                sprintf(buf,"%d",120);
                result = result + buf +" \n";
            }
            else
			result="call \n";			
		}
		else if (Formula_Left>0.3 && least_call +  bet_in_turn<= 8*small_blind)
		{
            if(bet_in_turn+least_call<= 6*small_blind)
            {
                result = "raise ";
                char buf[8];
                sprintf(buf,"%d",6*small_blind-least_call-bet_in_turn);
                result = result + buf +" \n";
            }
            else
			result="call \n";			
		}
        else if(least_call == 2*small_blind && bet_in_turn ==0 && (num/2.0 +1-before_players )<=0)//0.3>Formula_Left > 0
        {
            result = "call \n";
        }
		else
		{
			result="fold \n";			
		}
        return result;
	}
}
//ת�ƽ׶���Ҫ�ľ�����Ϊ
string Action_Of_Inquire_Six_Cards(double weight,int jetton,int TotalPot,int least_call,int bet_in_turn,int small_blind,int PlayerNum,int g_Seat,Card* hand_cards,Card* Pub_Cards,int money)
{
    Card* m_temp =new Card[7];
	for (int k=0;k<6;k++)
	{
		if (k<2)
			m_temp[k]=hand_cards[k];
		else
			m_temp[k]=Pub_Cards[k-2];
	}
	long long cardvalue = GetCT_Value(m_temp,7);

	string result;
	if (weight == 1)//�Ѿ�����
	{
		if (cardvalue < 40000000000)//����
		{
			if (least_call + bet_in_turn < TotalPot/PlayerNum)
			{
				result="raise ";
				char buf[8];
				sprintf(buf,"%d",TotalPot/PlayerNum-least_call-bet_in_turn);
				result=result+buf+" \n";
			} 
			else if (least_call+bet_in_turn <= 25*small_blind && least_call < jetton)
			{
				result = "call \n";
			}
			else
			{
				result = "fold \n";
			}
		}
		else
		{
			if (least_call + bet_in_turn < TotalPot/3)
			{
				result="raise ";
				char buf[8];
				sprintf(buf,"%d",TotalPot/3 - least_call - bet_in_turn);
				result=result+buf+" \n";
			} 
		    else if(money > 100 ) 
			    result = "call \n";
			else 
				result = "fold \n";
		}
	} 
	else//��û�г���
	{
		if ((double)least_call > weight*(double)(TotalPot+least_call))
		{
			result = "fold \n";
		}
		else 
        {
            if ((double)least_call < weight*(double)(TotalPot+least_call)*2/3 &&bet_in_turn == 0 )
	    	{
		    	 result="raise ";
		    	char buf[8];
		    	sprintf(buf,"%d",int(weight*(double)(TotalPot+least_call)*2/3 - (double)least_call));
		    	result=result+buf+" \n";
		    } 
            else 
                result = "call \n";
        }
	}
	return result;
}

//���ƽ׶���Ҫ�ľ�����Ϊ
string Action_Of_Inquire_Seven_Cards(double weight,int jetton,int TotalPot,int bet_of_all,int least_call,int bet_in_turn,int small_blind,int PlayerNum,int before_players,int money)
{
	double Formula_Left=pow(weight,PlayerNum);
	double Formula_Right=(double)(bet_of_all+least_call)/(double)TotalPot*Alpha + (double)least_call/(double)jetton*Beta;
	
	if (Formula_Left <= 0.5 && PlayerNum>=4 )
	{
        if(least_call > 0)
        {
	        string result = "fold \n";
	        return result;
        }
        else
        {
            string result = "check \n";
            return result;
        }
	}
	
	if (least_call == 0)//���ǰ����˶�û�м�ע
	{
        if(1 - Formula_Left < 0.01)
        {
            string result = "raise ";
            char buf[8];
            sprintf(buf, "%d", 4 * small_blind);
            result = result + buf + " \n";
            return result;
        }
		else if (Formula_Left >= 0.9)//ȷ���Լ����ƴ���90%�����
		{
			
			string result="raise ";
			char buf[8];
			sprintf(buf,"%d",4 * small_blind);
			result=result+buf+" \n";
            return result;
		} 
        else if(Formula_Left >= 0.8)
        {
            string result = "raise ";
            char buf[8];
            sprintf(buf,"%d",small_blind*(9-PlayerNum));
            result = result + buf +" \n";
            return result;
        }
        else if(Formula_Left >= 0.7)
        {
            if (before_players >=4) //�����ƱȽϴ�
            {
                    
            string result = "raise ";
            char buf[8];
            sprintf(buf, "%d", small_blind*(9-PlayerNum) + before_players * small_blind);
            result = result + buf + " \n";
            return result;
            }
             else 
            {         
            string result = "raise ";
            char buf[8];
            sprintf(buf, "%d", 2 * small_blind);
            result = result + buf + " \n";
            return result;
            }
        }
		else
		{
			string result="check \n";
            return result;
		}
	} 
	else//��ע��� 
	{
		string result;
        if (1 - Formula_Left < 0.01)
        {
            string result = "raise ";
            char buf[8];
            sprintf(buf, "%d", 4 * small_blind);
            result = result + buf + " \n";
            return result;

        }
		else if (Formula_Left > 0.95 && least_call +  bet_in_turn <= 100*small_blind)
		{
                result = "raise ";
                char buf[8];
                sprintf(buf, "%d", 2 * small_blind);
                result = result + buf + " \n";
                return result; 
        }
        else if (Formula_Left > 0.95 && least_call +  bet_in_turn > 100 * small_blind)
        {
            if (money > 100)
            {
            result = "call \n";
            return result;
            }
            else
            {
                result = "fold \n";
                return result;
            }
        }
		else if (Formula_Left > 0.9 && least_call +  bet_in_turn <= 70*small_blind)
		{ 
            result = "raise ";
            char buf[8];
            sprintf(buf, "%d", 2 * small_blind);
            result = result + buf + " \n";
            return result;
        }
		else if (Formula_Left>0.8 && least_call +  bet_in_turn<= 50*small_blind)
		{
			result  = "raise ";
            char buf[8]; 
            sprintf(buf, "%d", small_blind);
		}
		else if (Formula_Left>0.7 && least_call <= 8*small_blind && bet_in_turn<=12*small_blind)
		{
           if (m_raiseNum >=3)
            {
                result = "fold \n";
            }
           else  if (m_raiseNum >= 1 && m_callNum >=4)
            {
                result = "fold \n";
            }
            else
            {
             result = "call \n";    
            }
		}
		else if (Formula_Left>0.6 && least_call <= 4*small_blind && bet_in_turn<= 8*small_blind)
		{
           if (m_raiseNum >=3)
            {
                result = "fold \n";
            }
           else  if (m_raiseNum >= 1 && m_callNum >=4)
            {
                result = "fold \n";
            }
            else
            {
             result = "call \n";    
            }
		}
		else
		{
			result = "fold \n";
		}
        return result;
	}
}
#endif
